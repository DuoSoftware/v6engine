package configuration

type RoutingKeys struct {
	Keys map[string]string
}
